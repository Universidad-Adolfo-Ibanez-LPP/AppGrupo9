#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
    int opcion = 0;
    char agregar_eliminarlibro;
    char libro_a_cambiar;
    char libro_nuevo;
    char libro_cambios;
    char sede_cambiada;
    char seccion_cambio;
    char seccion_cambiada;
    char sede_a_eliminar;
    char sede_a_agregar;
    char sec_a_eliminar;
    char sec_a_agregar;
    char titulon; //titulo Nuevo, asi ctte
    char autorn;
    char anion;
    char estante_numeron;
    char estante_seccionn;
    char pison;
    char edificion;
    char seden;


    while (true)
    {

        printf("Lista de acciones disponibles: \n \t 1. Agregar o eliminar libro. \n \t 2. Editar libro \n \t 3. Editar sede \n \t 4. Cambiar pisos. \n \t 5. Editar sección.\n \t 6. Eliminar una sección.\n \t 7. Agregar una sección.\n \t 8. Eliminar una sede.\n \t 9. Agregar una sede.\n \t 10. Buscar un libro. \n \t 11. Salir del menú. \n ¿Que opcion desea?: " );
        scanf("%d", &opcion);


        switch (opcion)
        {

            case 1:
                printf("¿Desea \"agregar\" o \"eliminar\" un libro? : ");
                scanf("%c", &agregar_eliminarlibro);
                if (&agregar_eliminarlibro == "agregar") {


                    printf("Ingrese los siguientes datos del nuevo libro: titulo,autor,anio,estante_numero,estante_seccion,piso, edificio, sede");
                    scanf("%c", &titulon);
                    scanf("%c", &titulon);
                    scanf("%c", &autorn);
                    scanf("%c", &anion);
                    scanf("%c", &estante_numeron);
                    scanf("%c", &estante_seccionn);
                    scanf("%c", &pison);
                    scanf("%c", &edificion);
                    scanf("%c", &seden);
                    DataRow myFile = myFile.NewRow();
                    myFile["titulo"] = titulon;
                    myFile["autor"] = autorn;
                    myFile["anio"] = anion;
                    myFile["estante_numero"] = estante_numeron;
                    myFile["estante_seccion"] = estante_seccionn;
                    myFile["piso"] = pison;
                    myFile["edificio"] = edificion;
                    myFile["sede"] = seden;
                    printf("Nuevo libro agregado.");
                }
                if (&agregar_eliminarlibro == "eliminar")
                {
                    printf("¿Que libro deseas eliminar?:");
                    scanf("%c", titulon);
                    for (int i = 0; i < myFile.Rows.Count; i++)
                    {
                        DataRow dr = myFile.Rows[i];
                        if (dr["titulo"] == titulon)
                            dr.Delete();
                    }
                    myFile.acceptchanges()
                }

                break;

            case 2: //editar libro
                printf("Ingrese el titulo del libro que quieres cambiar:");
                scanf("%c", &libro_a_cambiar);
                for (int i = 0; i<myFile.Rows.Counts; i++)
                {
                    if (libro_a_cambiar == myFile[i, "titulo"])
                    {
                        printf("¿Nombre nuevo del libro");
                        scanf("%c", libro_nuevo);
                        myFile[i, "titulo"] = libro_nuevo;
                    }
                }

                break;

            case 3: //editar sede
                // sede es columna 9
                printf("Ingrese el titulo del libro cuya sede deseas cambiar:");
                scanf("%c", &libro_cambios);
                for (int i = 0; i<myFile.Rows.Counts; i++)
                {
                    if (libro_cambios == myFile[i, "titulo"])
                    {
                        printf("¿Nombre de la nueva sede del libro %c?:", &libro_cambios);
                        scanf("%c", sede_cambiada);
                        myFile[i, "sede"] = sede_cambiada;
                    }
                }

                break;

            case 4: //editar piso
                printf("Ingrese el titulo del libro cuyo piso deseas cambiar:");
                scanf("%c", &libro_cambios);
                for (int i = 0; i<myFile.Rows.Counts; i++)
                {
                    if (libro_cambios == myFile[i, "piso"])
                    {
                        printf("¿Nombre del nuevo del libro %c?:", &libro_cambios);
                        scanf("%c", opcion3);
                        myFile[i, "piso"] = opcion3;
                    }
                }

                break;

            case 5: //editar seccion
                printf("Ingrese el titulo del libro cuyo sección deseas cambiar:");
                scanf("%c", &libro_cambios);
                for (int i = 0; i<myFile.Rows.Counts; i++)
                {
                    if (libro_cambios == myFile[i, "estante_seccion"])
                    {
                        printf("¿Nombre de la nueva sección del libro %c?:", &libro_cambios);
                        scanf("%c", seccion_cambio);
                        myFile[i, "estante_seccion"] = seccion_cambio;
                    }
                }

                break;

            case 6: //eliminar sede solo si no tiene libros asociados
                // sede es columna 9
                printf("Ingrese la sede que quiere eliminar:");
                scanf("%c", &sede_a_eliminar);
                for (int i=0; i<myFile.Rows.Counts;i++){
                    if (sede_a_eliminar == myFile[i,"sede"] || myFile[i,"titulo"==" "]){
                        DataRow dr = myFile.Rows[i];
                        dr.Delete();
                    }
                myFile.acceptchanges()
                    }
                }
                break;

            case 7: //agregar sede
                printf("Ingrese el nombre de la sede que quiera agregar (tenga en cuenta que esta sede estará sin ningún libro asociado):");
                scanf("%c", &sede_a_agregar);
                int i = myFile.Rows.Count + 1;
                sede_a_agregar = myFile[i, "sede"];
                break;

            case 8: //eliminar seccion solo si no tiene libros asociados
                // sede es columna 9
                printf("Ingrese la seccion que quiere eliminar:");
                scanf("%c", &sec_a_eliminar);
                for (int i=0; i<myFile.Rows.Counts;i++){
                    if (sec_a_eliminar == myFile[i,"estante_seccion"] || myFile[i,"titulo"==" "]){
                    DataRow dr = myFile.Rows[i];
                    dr.Delete();
                }
                myFile.acceptchanges() }
                break;

            case 9: //agregar sec
                printf("Ingrese el nombre de la sección que quiera agregar (tenga en cuenta que esta sección estará sin ningún libro asociado):");
                scanf("%c", &sec_a_agregar);
                int i = myFile.Rows.Count + 1;
                sede_a_agregar = myFile[i, "estante_seccion"];
                break;


            case 10: //buscar un libro
                printf("Ingrese el titulo del libro que busca:");
                scanf("%c", &libro_cambios);
                for (int i = 0; i<myFile.Rows.Counts; i++)
                {
                    if (libro_cambios == myFile[i, "titulo"])
                    {
                        printf("Los datos del libro que buscas son: ");
                        for (int j = 0; j<myFile.Columns.Counts; j++)
                        {
                            printf(myFile[i,j])
                        }

                    }
                }
                break;

            case 11:
                exit(0);
        }

    }

    return 0;
}
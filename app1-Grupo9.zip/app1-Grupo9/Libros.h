struct Libros {
    int  id;
    char  *titulo;
    char  *autor;
    char  *anio;
    char   *estante_numero;
    char   *estante_seccion;
} ;

typedef struct Libros Libro;

extern int registryCount;

Libro* getLibros(FILE *fp);

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "Libros.h"
#include "Utils.h"

#define MAXCHAR 1000

int registryCount = 0;

Libro *getLibros(FILE *fp) {
    //genero un array dinamico de libros
    Libro *libros = (Libro*) malloc(5000*sizeof(Libro));;

    char row[MAXCHAR];
    char *token;
    int cont = 0;
    //saco la primer linea
    fgets(row, MAXCHAR, fp);
    while (!feof(fp)){
        if (!feof(fp)){
            //obtiene la linea siguiente
            fgets(row, MAXCHAR, fp);
            token = strtok(row, ",");
            //print titulo first
            Libro  *libro = (Libro *) malloc(sizeof(Libro));;
            //convierto el id en entero
            char *titulo;
            //lo paso al libro
            libro->titulo = titulo;

            //obtengo el siguiente campo
            token = strtok(NULL, ",");
            //inicializo el string en la estructura acorde al tamaño que venga del archivo
            libro->autor = (char*)malloc( strlen(token) * sizeof(char));
            //finalmente lo copio en el campo de libro
            strcpy( libro->autor, token);

            //obtengo el siguiente campo
            token = strtok(NULL, ",");
            //inicializo el string en la estructura acorde al tamaño que venga del archivo
            libro->anio = (char*)malloc( strlen(token) * sizeof(char));
            //finalmente lo copio en el campo de libro
            strcpy( libro->anio, token);

            //obtengo el siguiente campo
            token = strtok(NULL, ",");
            //inicializo el string en la estructura acorde al tamaño que venga del archivo
            libro->estante_numero = (char*)malloc( strlen(token) * sizeof(char));
            //finalmente lo copio en el campo de libro
            strcpy( libro->estante_numero, token);

            //obtengo el siguiente campo
            token = strtok(NULL, ",");
            //inicializo el string en la estructura acorde al tamaño que venga del archivo
            libro->estante_seccion = (char*)malloc( strlen(token) * sizeof(char));
            //finalmente lo copio en el campo de libro
            strcpy( libro->estante_seccion, token);

            //obtengo el siguiente campo
            token = strtok(NULL, ",");
            //inicializo el string en la estructura acorde al tamaño que venga del archivo
            libro->edificio = (char*)malloc( strlen(token) * sizeof(char));
            //finalmente lo copio en el campo de libro
            strcpy( libro->edificio, token);

            //obtengo el siguiente campo
            token = strtok(NULL, ",");
            //inicializo el string en la estructura acorde al tamaño que venga del archivo
            libro->piso = (char*)malloc( strlen(token) * sizeof(char));
            //finalmente lo copio en el campo de libro
            strcpy( libro->piso, token);

            //obtengo el siguiente campo
            token = strtok(NULL, ",");
            //inicializo el string en la estructura acorde al tamaño que venga del archivo
            libro->sede = (char*)malloc( strlen(token) * sizeof(char));
            //finalmente lo copio en el campo de libro
            strcpy( libro->sede, token);

            //seteo borrar por defecto en 0
            libro->borrar = 0;

            libros[cont] = *libro;
            cont++;
        }
    }
    //guardo la cantidad de registros que lei
    registryCount = cont;
    return libros;
}

void writeLibros(Libro *libros, FILE *fp){
    //Escribo la primer linea
    fprintf(fp,"titulo,autor,anio,estante_numero,estante_seccion,edificio,piso,sede\n");
    //escribo las siguientes
    for (int i = 0; i < registryCount; ++i) {
        //solo escribo sino puse para borrar a esa libro
        if (libros[i].borrar == 0){
            fprintf(fp,"%s,%s,%s,%s,%s", libros[i].titulo, libros[i].autor, libros[i].anio, libros[i].estante_seccion, libros[i].estante_numero, libros[i].edificio, libros[i].piso, libros[i].sede);
        }
    }
}

void agregarLibros() {
    //genero espacio para crear un libro
    Libro  *libro = (Libro *) malloc(sizeof(Libro));
    //comienzo a pedir los datos
    printf("Ingrese el titulo \n");
    char titulo;
    scanf("%c", &titulo);
    libro->titulo = titulo;

    char token = (char*)malloc( 50 * sizeof(char));
    printf("Ingrese el autor \n");
    scanf("%s", &token);
    //genero memoria para el nombre en nuestra estructura libro
    libro->autor = (char*)malloc(strlen(token)* sizeof(char));
    //recien ahora tengo lugar para copiar el nombre
    strcpy(libro->autor, token);

    printf("Ingrese el año \n");
    scanf("%s", &token);
    //genero memoria para el nombre en nuestra estructura libro
    libro->anio = (char*)malloc( strlen(token) * sizeof(char));
    //recien ahora tengo lugar para copiar el nombre
    strcpy(libro->anio, token);

    printf("Ingrese el núm. de estante \n");
    scanf("%s", &token);
    //genero memoria para el nombre en nuestra estructura libro
    libro->estante_numero = (char*)malloc( strlen(token) * sizeof(char));
    //recien ahora tengo lugar para copiar el nombre
    strcpy(libro->estante_numero, token);

    printf("Ingrese la sección del estante \n");
    scanf("%s", &token);
    //genero memoria para el nombre en nuestra estructura libro
    libro->estante_seccion = (char*)malloc( strlen(token) * sizeof(char));
    //recien ahora tengo lugar para copiar el nombre
    strcpy(libro->estante_seccion, token);

    //pongo en 0 el borrado, por que por defecto no esta para borrarse
    libro->borrar = 0;

    //ahora lo puedo agregar al final de mi array, por lo que
    //actualizo mi contador de registros
    //lo tiro al final del arreglo
    libros = (Libro*) realloc(libros, (registryCount+1)*sizeof(Libro));
    libros[registryCount] = *libro;
    registryCount++;
    printf("Agregado con exito! \n");
}

void agregarSede() {
    //genero espacio para crear un libro
    Libro  *libro = (Libro *) malloc(sizeof(Libro));
    //comienzo a pedir los datos
    printf("Ingrese el nombre de la sede (tenga en cuenta que se creará una sede en blanco): \n");
    char sede;
    scanf("%c", &sede);
    libro->sede = sede;

    //pongo en 0 el borrado, por que por defecto no esta para borrarse
    libro->borrar = 0;

    //ahora lo puedo agregar al final de mi array, por lo que
    //actualizo mi contador de registros
    //lo tiro al final del arreglo
    libros = (Libro*) realloc(libros, (registryCount+1)*sizeof(Libro));
    libros[registryCount] = *libro;
    registryCount++;
    printf("Agregado con exito! \n");
}
void agregarSeccion() {
    //genero espacio para crear un libro
    Libro  *libro = (Libro *) malloc(sizeof(Libro));
    //comienzo a pedir los datos
    printf("Ingrese el nombre de la sección nueva (tenga en cuenta que se creará una sección en blanco): \n");
    char estante_seccion;
    scanf("%c", &estante_seccion);
    libro->estante_seccion = estante_seccion;

    //pongo en 0 el borrado, por que por defecto no esta para borrarse
    libro->borrar = 0;

    //ahora lo puedo agregar al final de mi array, por lo que
    //actualizo mi contador de registros
    //lo tiro al final del arreglo
    libros = (Libro*) realloc(libros, (registryCount+1)*sizeof(Libro));
    libros[registryCount] = *libro;
    registryCount++;
    printf("Agregado con exito! \n");
}

void agregarPiso() {
    //genero espacio para crear un libro
    Libro  *libro = (Libro *) malloc(sizeof(Libro));
    //comienzo a pedir los datos
    printf("Ingrese el nombre del piso (tenga en cuenta que se creará un piso en blanco): \n");
    char piso;
    scanf("%c", &piso);
    libro->piso = piso;

    //pongo en 0 el borrado, por que por defecto no esta para borrarse
    libro->borrar = 0;

    //ahora lo puedo agregar al final de mi array, por lo que
    //actualizo mi contador de registros
    //lo tiro al final del arreglo
    libros = (Libro*) realloc(libros, (registryCount+1)*sizeof(Libro));
    libros[registryCount] = *libro;
    registryCount++;
    printf("Agregado con exito! \n");
}

void eliminarLibro() {
    char *name = (char*)malloc( 50 * sizeof(char));;
    printf("Ingrese el nombre del libro a eliminar \n");
    scanf("%s", name);
    //Hago una busqueda linea
    int i = 0;
    int encontre = 0;
    while (i<registryCount && encontre == 0){
        char *nameConverted = toLowerC(libros[i].titulo);
        char *nameToLook = toLowerC(name);
        char *ret = strstr(nameConverted, nameToLook);
    }
    //verifico que sali por que encontre
    if (encontre == 1){
        //la dejo marcada para borrar
        libros[i].borrar = 1;
        printf("Borrado con Exito! \n");
    }
}

void eliminarSede() {
    char *name = (char*)malloc( 50 * sizeof(char));;
    printf("Ingrese el nombre de la sede a eliminar \n");
    scanf("%s", name);
    //Hago una busqueda linea
    int i = 0;
    int encontre = 0;
    while (i<registryCount && encontre == 0){
        char *nameConverted = toLowerC(libros[i].sede);
        char *nameToLook = toLowerC(name);
        char *ret = strstr(nameConverted, nameToLook);
    }
    //verifico que sali por que encontre
    if (encontre == 1 && (libros[i].titulo == " " || libros[i].titulo == "")){
        //la dejo marcada para borrar
        libros[i].borrar = 1;
        printf("Borrado con Exito! \n");
    }
    else {
    printf("Esta sede tiene un libro asociado");
    }
}

void eliminarSeccion() {
    char *name = (char*)malloc( 50 * sizeof(char));;
    printf("Ingrese el nombre de la sección a eliminar \n");
    scanf("%s", name);
    //Hago una busqueda linea
    int i = 0;
    int encontre = 0;
    while (i<registryCount && encontre == 0){
        char *nameConverted = toLowerC(libros[i].estante_seccion);
        char *nameToLook = toLowerC(name);
        char *ret = strstr(nameConverted, nameToLook);
    }
    //verifico que sali por que encontre
    if (encontre == 1 && (libros[i].titulo == " " || libros[i].titulo == "")){
        //la dejo marcada para borrar
        libros[i].borrar = 1;
        printf("Borrado con Exito! \n");
    }
    else {
        printf("Esta sección tiene un libro asociado");
    }
}

void eliminarPiso() {
    char *name = (char*)malloc( 50 * sizeof(char));;
    printf("Ingrese el nombre del piso a eliminar \n");
    scanf("%s", name);
    //Hago una busqueda linea
    int i = 0;
    int encontre = 0;
    while (i<registryCount && encontre == 0){
        char *nameConverted = toLowerC(libros[i].piso);
        char *nameToLook = toLowerC(name);
        char *ret = strstr(nameConverted, nameToLook);
    }
    //verifico que sali por que encontre
    if (encontre == 1 && (libros[i].titulo == " " || libros[i].titulo == "")){
        //la dejo marcada para borrar
        libros[i].borrar = 1;
        printf("Borrado con Exito! \n");
    }
    else {
        printf("Este piso tiene un libro asociado");
    }
}

void mostrarLibros() {
    printf("Ingrese el título del libro que busca: ");
    char *name = (char*)malloc( 50 * sizeof(char));
    scanf("%s", name);
    //Hago una busqueda linea
    int i = 0;
    int encontre = 0;
    while (i<registryCount && encontre == 0){
        char *nameConverted = toLowerC(libros[i].titulo);
        char *nameToLook = toLowerC(name);
        char *ret = strstr(nameConverted, nameToLook);
        //valido que la encuentro y que no la borre antes
        if(ret && libros[i].borrar == 0){
            encontre = 1;
        } else {
            i++;
        }
    }
    //verifico que sali por que encontre
    if (encontre == 1){
        printf("Estos son los datos del libro: \n");
        printf("%s,%s,%s,%s,%s,%s,%s,%s. \n", libros[i].titulo, libros[i].autor, libros[i].anio, libros[i].estante_seccion, libros[i].estante_numero, libros[i].edificio, libros[i].piso, libros[i].sede);
    } else {
        printf("El libro no existe! \n");
    }

}

void editarLibro(){
    char *name = (char*)malloc( 50 * sizeof(char));;
    printf("Ingrese el nombre del libro que quieres editar \n");
    scanf("%s", name);
    //Hago una busqueda linea
    int i = 0;
    int size = sizeof(libros->titulo);
    for (i=0; i<size; i++) {
        if (libros[i].titulo == name){
            enum OPTIONS { TITULO = 1, SECCION = 2, SEDE = 3, PISO = 4};
            printf("Elija el campo que quiere editar: \n");
            printf("TITULO, SECCIÓN, SEDE O PISO");
            char option;
            scanf("%d", &option);
            switch (option){
                case TITULO:
                    printf("Escriba su nuevo título: \n");
                    char *nuevo_titulo;
                    strcpy(libros[i].titulo,nuevo_titulo);
                    break;
                case SECCION:
                    printf("Escriba su nueva sección: \n");
                    char *nuevo_seccion;
                    strcpy(libros[i].estante_seccion,nuevo_seccion);
                case SEDE:
                    printf("Escriba su nueva sede: \n");
                    char *nuevo_sede;
                    strcpy(libros[i].sede,nuevo_sede);
                    break;
                case PISO:
                    printf("Escriba el nuevo piso para su libro: \n");
                    char *nuevo_piso;
                    strcpy(libros[i].piso,nuevo_piso);
            }
        }
    }
}
